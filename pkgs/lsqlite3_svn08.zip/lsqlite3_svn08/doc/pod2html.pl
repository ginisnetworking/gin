#!perl

use Pod::Html;

pod2html @ARGV;

__END__
