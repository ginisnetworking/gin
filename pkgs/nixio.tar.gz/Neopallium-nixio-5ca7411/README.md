NIXIO
=====

This Git repository is a fork of the [NIXIO code from the LuCI project](http://luci.subsignal.org/).  I created this fork to make it easier to track my changes & fixes.

Building:
---------

	Use GNU Make.
	make or gmake depending on your system.
	
	Special make flags:

	OS		Override Target OS	[Linux|FreeBSD|SunOS|Windows]
	NIXIO_TLS	TLS-Library		[*openssl|axtls]
	NIXIO_CROSS_CC	MinGW CC (Windows)	`which i586-mingw32msvc-cc`
	LUA_CFLAGS	Lua CFLAGS		`pkg-config --cflags lua5.1`
	LUA_TARGET	Lua compile		target	[*source|strip|compile]
	LUA_MODULEDIR	Install LUA_PATH	"/usr/share/lua/5.1"
	LUA_LIBRARYDIR	Install LUA_CPATH	"/usr/lib/lua/5.1"

