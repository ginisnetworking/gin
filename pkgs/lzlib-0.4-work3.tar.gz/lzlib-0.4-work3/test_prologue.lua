print('lua version : ' .. _VERSION)
print('zlib version: ' .. (require('zlib')._VERSION))
