About
=====

Lua bindings to zeromq2.

Installation
============

<pre>
$ make install
</pre>

API
===

See [API.md](http://github.com/iamaleksey/lua-zmq/blob/master/API.md) and
[ØMQ docs](http://www.zeromq.org/area:docs-v20).
