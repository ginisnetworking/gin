
require 'Coat'

class 'MyApp.Bar'
